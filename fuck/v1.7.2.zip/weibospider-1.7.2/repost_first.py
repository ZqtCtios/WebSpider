# coding:utf-8
from tasks import repost


if __name__ == '__main__':
    repost.excute_repost_task()