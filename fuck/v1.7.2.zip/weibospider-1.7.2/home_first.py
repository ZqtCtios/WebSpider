# coding:utf-8
from tasks import home


if __name__ == '__main__':
    home.excute_home_task()