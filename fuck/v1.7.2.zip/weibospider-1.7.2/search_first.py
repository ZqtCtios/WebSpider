# coding:utf-8
from tasks import search

if __name__ == '__main__':
    search.excute_search_task()