# coding:utf-8
from tasks import user

if __name__ == '__main__':
    user.excute_user_task()